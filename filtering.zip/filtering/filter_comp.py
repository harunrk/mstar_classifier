import cv2
import numpy as np
import matplotlib.pyplot as plt
import pywt
from bm3d import bm3d

image_path = '../image_classes/2S1/HB14931.jpg'
image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

def lee_filter(img, size):
    mean = cv2.blur(img, (size, size)) 
    mean_sqr = cv2.blur(img**2, (size, size))
    variance = mean_sqr - mean**2  
    overall_variance = np.var(img)  
    img_filtered = mean + (variance / (variance + overall_variance)) * (img - mean)
    
    return img_filtered

def EAW(image, wavelet='db1', level=2):
    coeffs = pywt.wavedec2(image, wavelet, level=level)
    
    cA = coeffs[0]
    details = list(coeffs[1:])
    
    for i in range(len(details)):
        cH, cV, cD = details[i]
        details[i] = (
            pywt.threshold(cH, np.std(cH)),
            pywt.threshold(cV, np.std(cV)),
            pywt.threshold(cD, np.std(cD))
        )
    
    coeffs = [cA] + details
    denoised_image = pywt.waverec2(coeffs, wavelet)
    
    return denoised_image

bm3d_filtered_image = bm3d(image, sigma_psd=100) # 25-100
lee_filtered_image = lee_filter(image, 3) # 3-3
eaw_filtered_image = EAW(image=image, level=3) # 2-3
median_filtered_image = cv2.medianBlur(image, 7) # 5-7

plt.figure(figsize=(15, 10))

plt.subplot(2, 3, 1)
plt.title('Original')
plt.imshow(image, cmap='gray')

plt.subplot(2, 3, 2)
plt.title('EAW Wavelet')
plt.imshow(eaw_filtered_image, cmap='gray')

plt.subplot(2, 3, 3)
plt.title('BM3D')
plt.imshow(bm3d_filtered_image, cmap='gray')

plt.subplot(2, 3, 4)
plt.title('Lee Filter')
plt.imshow(lee_filtered_image, cmap='gray')

plt.subplot(2, 3, 5)
plt.title('Median Filter')
plt.imshow(median_filtered_image, cmap='gray')

plt.show()


