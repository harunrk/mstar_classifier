import cv2
import os
from bm3d import bm3d

path = '../image_classes'
filtered_path = '../bm3d_filtered_images'

if not os.path.exists(filtered_path):
    os.makedirs(filtered_path)

for folder in os.listdir(path):
    sub_folder_path = os.path.join(path, folder)
    filtered_sub_folder_path = os.path.join(filtered_path, folder)

    if not os.path.exists(filtered_sub_folder_path):
        os.makedirs(filtered_sub_folder_path)

    for image_name in os.listdir(sub_folder_path):
        image_path = os.path.join(sub_folder_path, image_name)
        image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
        filtered_image = bm3d(image, sigma_psd=100)
        filtered_image_path = os.path.join(filtered_sub_folder_path, image_name)

        cv2.imwrite(filtered_image_path, filtered_image)

